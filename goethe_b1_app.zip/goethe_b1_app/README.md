# 🇩🇪 Goethe B1 Kelime Öğrenimi

Goethe-Zertifikat B1 sınav kelime listesine dayanan, AI destekli Türkçe flashcard uygulaması.

## 🚀 Streamlit Community Cloud'a Deploy (ÜCRETSİZ)

### 1. GitHub'a Yükle

1. [github.com](https://github.com) → "New repository" → `goethe-b1` adıyla oluştur
2. Bu klasördeki tüm dosyaları yükle:
   - `app.py`
   - `words.json`
   - `requirements.txt`
   - `.streamlit/config.toml`

### 2. Streamlit'e Deploy Et

1. [share.streamlit.io](https://share.streamlit.io) → GitHub ile giriş yap
2. "New app" → GitHub repo'nu seç → `app.py` dosyasını seç
3. "Advanced settings" → Secrets kısmına ekle:
   ```
   ANTHROPIC_API_KEY = "sk-ant-..."
   ```
4. "Deploy!" → Birkaç dakika sonra linkin hazır!

### 3. API Anahtarı (AI Özelliği için)

AI örnek cümle özelliği için Anthropic API anahtarı gerekli:
- [console.anthropic.com](https://console.anthropic.com) → API Keys → Create Key
- Bu anahtarı Streamlit Secrets'a ekle (yukarıda adım 3)

## 💻 Yerel Çalıştırma

```bash
pip install -r requirements.txt
streamlit run app.py
```

## ✨ Özellikler

- 📇 **Flashcard** — Spaced repetition ile akıllı tekrar
- 📝 **Quiz** — Çoktan seçmeli test modu  
- 🤖 **AI Örnek Cümle** — Claude ile otomatik cümle üretimi
- 📖 **Kelime Listesi** — Arama ve filtreleme
- ➕ **Kelime Ekle** — Kendi kelimelerini ve CSV yükle
- 📊 **İstatistikler** — İlerleme takibi, zorlu kelimeler
- 🔥 **Streak Sistemi** — Günlük çalışma serisi

## 📂 Dosya Yapısı

```
goethe_b1_app/
├── app.py              # Ana uygulama
├── words.json          # 2663 kelime (Goethe B1)
├── requirements.txt    # Bağımlılıklar
└── .streamlit/
    └── config.toml     # Tema ayarları
```
